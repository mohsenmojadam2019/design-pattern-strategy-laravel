<?php

namespace App\Models;

interface TaxCalculatorStrategy
{
    public function calculate(Product $product): float;

}
