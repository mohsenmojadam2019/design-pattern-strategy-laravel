<?php

namespace App\Models;

class TaxFreeStrategy implements TaxCalculatorStrategy
{

    public function calculate(Product $product): float
    {
        return 0;
    }
}
